# split-workflow Workflow

Generating a Workflow
---------------------
Run the generate_dax.sh script.

Running a Workflow
-------------------
Run the plan_dax.sh script.
