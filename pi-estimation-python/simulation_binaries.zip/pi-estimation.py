import sys
import random
import math

num_of_samples = int(sys.argv[1])

#print "We will estimate PI based on", str(num_of_samples), "samples"

points_in_circle = 0
for i in range(1, num_of_samples):
    x = random.random()
    y = random.random()

    if x*x + y*y < 1:
        points_in_circle += 1

# pi*R^2 / 4 * R^2 = points_in_circle / num_of_samples

pi_estimation = 4.0*points_in_circle / num_of_samples
#print "We estimated PI to be", str(pi_estimation)
print pi_estimation

mse = (math.pi - pi_estimation)**2
#print "MSE =", str(mse)
print mse
